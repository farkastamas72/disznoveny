import { Component } from '@angular/core';

@Component({
  selector: 'app-rolunk',
  templateUrl: './rolunk.component.html',
  styleUrls: ['./rolunk.component.css']
})
export class RolunkComponent {

}
