export class Noveny {
    key?:string
    megnevezes?:string
    lerias?:string
    kepUrl?:string
    ar?:number
}
