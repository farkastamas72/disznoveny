import { Megrendeles } from './megrendeles';

describe('Megrendeles', () => {
  it('should create an instance', () => {
    expect(new Megrendeles()).toBeTruthy();
  });
});
