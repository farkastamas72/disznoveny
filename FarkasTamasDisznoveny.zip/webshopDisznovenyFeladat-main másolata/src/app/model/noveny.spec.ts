import { Noveny } from './noveny';

describe('Noveny', () => {
  it('should create an instance', () => {
    expect(new Noveny()).toBeTruthy();
  });
});
