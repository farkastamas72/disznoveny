export class Megrendeles {
    nev?:string
    cim?:string
    tetel?:[]
    datum?:string
    statusz?:string
}
