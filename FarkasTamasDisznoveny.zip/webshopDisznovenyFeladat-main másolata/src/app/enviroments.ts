export const Enviroments = {
    production:false,
    firebaseConfig : {
  apiKey: "AIzaSyAIAAoavgrrWmyNEc7FNtvvHXAAPug7pCw",
  authDomain: "disznoveny-1b5e1.firebaseapp.com",
  databaseURL: "https://disznoveny-1b5e1-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "disznoveny-1b5e1",
  storageBucket: "disznoveny-1b5e1.appspot.com",
  messagingSenderId: "976543934611",
  appId: "1:976543934611:web:8d086c2add409584a6c566"
    }
}
